import pygame
import random
import os

def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert_alpha()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image

def render_room(screen, maze, wall):
    screen.blit(wall.image, [wall.rect.x, wall.rect.y])
    maze.render()
    maze.drawblocks(screen)       

width = 1600
height = 900
screen = pygame.display.set_mode((width, height))
wg = pygame.sprite.Group()
wall = pygame.sprite.Sprite(wg)
wall.image = load_image("wall.png")
wall.image = pygame.transform.scale(wall.image, (1600, 900))
wall.rect = wall.image.get_rect()
wall.rect.x = 0
wall.rect.y = 0
screen.fill((255, 255, 255))
wg.draw(screen)
pygame.init()


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.left = 0
        self.top = 0
        self.cell_size = 100
        self.x = 0
        self.y = 0
        self.widthscreen = self.width * self.cell_size + (self.left * 2)
        self.heightscreen = self.height * self.cell_size + (self.top * 2)
        self.cells = {}
        self.num = 0

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self):
        for y in range(self.height):
            for x in range(self.width):
                pygame.draw.rect(screen, pygame.Color(70, 70, 70), (
                    x * self.cell_size + self.left, y * self.cell_size + self.top, self.cell_size, self.cell_size), 1)

    def get_cell(self, mouse_pos):
        x, y = mouse_pos
        x -= self.left
        x //= self.cell_size
        y -= self.left
        y //= self.cell_size
        return x, y


class Labyrinth(Board):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.blocks = pygame.sprite.Group()
        self.bc = []
        self.movingblocks = pygame.sprite.Group()
        self.mb = []
        self.mbc = []
        self.clock = pygame.time.Clock()
        
    def drawblocks(self, scr):
        self.blocks.draw(scr)
        self.movingblocks.draw(scr)

    def init_mazeblock(self, x, y, scr):
        block = pygame.sprite.Sprite(self.blocks)
        block.image = load_image("block.png")
        block.image = pygame.transform.scale(block.image, (100, 100))
        block.rect = block.image.get_rect()
        self.bc += [(x, y)]
        block.rect.x = x * 100
        block.rect.y = y * 100

    def init_mazemovingblock(self, x, y, scr):
        block = pygame.sprite.Sprite(self.movingblocks)
        block.image = load_image("movingblock.png")
        block.image = pygame.transform.scale(block.image, (100, 100))
        block.rect = block.image.get_rect()
        self.mbc += [(x, y)]
        self.mb += [block]
        block.rect.x = x * 100
        block.rect.y = y * 100

    def blockcoords(self):
        return self.bc

    def movingblockcoords(self):
        return self.mbc
    
    def moveblock(self, n, xy, pm, scr, wall, hero, finish):
        if xy == "x":
            if pm == "+":
                if hero.moveright(scr, wall, maze, finish, self.mb[n]):
                    x, y = self.mbc[n]
                    self.mbc[n] = x + 1, y
            if pm == "-":
                if hero.moveleft(scr, wall, maze, finish, self.mb[n]):
                    x, y = self.mbc[n]
                    self.mbc[n] = x - 1, y
        if xy == "y":
            if pm == "+":
                if hero.movedown(scr, wall, maze, finish, self.mb[n]):
                    x, y = self.mbc[n]
                    self.mbc[n] = x, y + 1
            if pm == "-":
                if hero.moveup(scr, wall, maze, finish, self.mb[n]):
                    x, y = self.mbc[n]
                    self.mbc[n] = x, y - 1
        
    def reinit(self, n, m, scr, xy):
        self.blocks = pygame.sprite.Group()
        self.bc = []
        self.mb = []
        self.mbc = []
        x, y = xy
        self.movingblocks = pygame.sprite.Group()
        for i in range(n):
            xy1 = [x, y]
            while xy1 == [x, y] or tuple(xy1) in self.bc or tuple(xy1) in self.mbc or xy1 == [0, 0]: 
                x1, y1 = random.randint(0, 15), random.randint(0, 8)
                xy1 = [x1, y1]
            self.init_mazeblock(x1, y1, scr)
        for i in range(m):
            xy1 = [x, y]
            while xy1 == [x, y] or tuple(xy1) in self.bc or tuple(xy1) in self.mbc or xy1 == [0, 0]: 
                x1, y1 = random.randint(0, 15), random.randint(0, 8)
                xy1 = [x1, y1]
            self.init_mazemovingblock(x1, y1, scr)
        self.drawblocks(scr)

class Hero:
    def __init__(self):
        self.hg = pygame.sprite.Group()
        self.hero = pygame.sprite.Sprite(self.hg)
        self.hero.image = load_image("hero.png")
        self.hero.image = pygame.transform.scale(self.hero.image, (98, 98))
        self.hero.rect = self.hero.image.get_rect()
        self.hero.rect.x = 1
        self.hero.rect.y = 1
        self.clock = pygame.time.Clock()

    def moveup(self, scr, wall, maze, finish, block=False):
        if block:
            min_y = 200
        else:
            min_y = 100
        if self.hero.rect.y > min_y:
            for i in range(25):
                render_room(scr, maze, wall)
                self.clock.tick(25)
                self.hero.rect.y -= 4
                if block:
                    block.rect.y -= 4
                self.drawhero(scr, wall, finish, block)
            return True
        else:
            return False
    
    def movedown(self, scr, wall, maze, finish, block=False):
        if block:
            max_y = 700
        else:
            max_y = 800
        if self.hero.rect.y < max_y:
            for i in range(25):
                render_room(scr, maze, wall)
                self.clock.tick(25)
                self.hero.rect.y += 4
                if block:
                    block.rect.y += 4
                self.drawhero(scr, wall, finish, block)
            return True
        else:
            return False

    def moveleft(self, scr, wall, maze, finish, block=False):
        if block:
            min_x = 200
        else:
            min_x = 100
        if self.hero.rect.x > min_x:
            for i in range(25):
                render_room(scr, maze, wall)
                self.clock.tick(25)
                self.hero.rect.x -= 4
                if block:
                    block.rect.x -= 4
                self.drawhero(scr, wall, finish, block)
            return True
        else:
            return False        

    def moveright(self, scr, wall, maze, finish, block=False):
        if block:
            max_x = 1400
        else:
            max_x = 1500
        if self.hero.rect.x < max_x:
            for i in range(25):
                render_room(scr, maze, wall)
                self.clock.tick(25)
                self.hero.rect.x += 4
                if block:
                    block.rect.x += 4
                self.drawhero(scr, wall, finish, block)
            return True
        else:
            return False        
        
    def movetostart(self, scr, wall, maze, fin):
        render_room(scr, maze, wall)
        self.hero.rect.x = 1
        self.hero.rect.y = 1
        self.drawhero(scr, wall, fin)    

    def drawhero(self, scr, wall, finish, block=False):
        scr.blit(self.hero.image, [self.hero.rect.x, self.hero.rect.y])
        if block:
            scr.blit(block.image, [block.rect.x, block.rect.y])
        finish.drawfinish(scr)
        pygame.display.flip()
    
    def herosprite(self):
        return self.hero
        
    def coords(self):
        return [(self.hero.rect.x - 1) // 100, (self.hero.rect.y - 1) // 100]

        
class Finish():
    def __init__(self):
        self.x = 15
        self.y = random.randint(0, 8)
        self.coord = self.x, self.y
        self.cond = False
        self.fsprite = pygame.sprite.Sprite()
        self.fsprite.image = load_image("finish.png")
        self.fsprite.image = pygame.transform.scale(self.fsprite.image, (100, 100))
        self.fsprite.rect = self.fsprite.image.get_rect()
        self.fsprite.rect.x = self.x * 100
        self.fsprite.rect.y = self.y * 100

    def finish(self, coords1):
        if tuple(coords1) == self.coord:
            self.cond = True

    def finished(self):
        if self.cond:
            return True

    def coords(self):
        return self.coord
    
    def drawfinish(self, scr):
        scr.blit(self.fsprite.image, [self.fsprite.rect.x, self.fsprite.rect.y])
        pygame.display.flip()
    
    def restart(self):
        self.cond = False

hero = Hero()
pygame.init()
maze=Labyrinth(16, 9)
motion = ''
close = False
font = pygame.font.Font(None, 25)
for lvl in range(1, 7):
    running = True
    if lvl < 6:
        fin = Finish()
    hero.drawhero(screen, wall, fin)
    block = False
    fcoords = list(fin.coords())
    if lvl == 1:
        text1 = font.render("Lvl: 1", 1, (255, 0, 0))
        text1_x=1
        text1_y=1
        screen.blit(text1, (text1_x, text1_y))
        maze.reinit(10, 2, screen, fcoords)
        text = font.render("Для управления используйте клавиши WASD или стрелки, для перезапуска уровня нажмите ПРОБЕЛ. Для перехода в бесконечный режим нажмите i, для перехода обратно в обычный нажмите o.", 1, (255, 0, 0))
        text_x=width // 2 - text.get_width() // 2
        text_y=height // 2 - text.get_height() // 2
        text_w=text.get_width()
        text_h=text.get_height()
        screen.blit(text, (text_x, text_y))
    if lvl == 2:
        text1 = font.render("Lvl: 2", 1, (255, 0, 0))
        text1_x=1
        text1_y=1
        screen.blit(text1, (text1_x, text1_y))        
        maze.reinit(30, 6, screen, fcoords)
        hero.movetostart(screen, wall, maze, fin)
    if lvl == 3:
        text1 = font.render("Lvl: 3", 1, (255, 0, 0))
        text1_x=1
        text1_y=1
        screen.blit(text1, (text1_x, text1_y))
        maze.reinit(30, 10, screen, fcoords)
        hero.movetostart(screen, wall, maze, fin)
    if lvl == 4:
        text1 = font.render("Lvl: 4", 1, (255, 0, 0))
        text1_x = 1
        text1_y = 1
        screen.blit(text1, (text1_x, text1_y))
        maze.reinit(20, 20, screen, fcoords)
        hero.movetostart(screen, wall, maze, fin)
    if lvl == 5:
        text1 = font.render("Lvl: 5", 1, (255, 0, 0))
        text1_x = 1
        text1_y=1
        screen.blit(text1, (text1_x, text1_y))
        maze.reinit(5, 40, screen, fcoords)
        hero.movetostart(screen, wall, maze, fin)
    if lvl == 6:
        text = font.render("Поздравляем, Вы выиграли!", 1, (255, 0, 0))
        text_x=width // 2 - text.get_width() // 2
        text_y=height // 2 - text.get_height() // 2
        text_w=text.get_width()
        text_h=text.get_height()
        screen.blit(text, (text_x, text_y))
    while running:
        if not block:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w or event.key == pygame.K_UP:
                        motion = 'UP'
                    if event.key == pygame.K_s or event.key == pygame.K_DOWN:
                        motion = 'DOWN'
                    if event.key == pygame.K_a or event.key == pygame.K_LEFT:
                        motion = 'LEFT'
                    if event.key == pygame.K_d or event.key == pygame.K_RIGHT:
                        motion = 'RIGHT'
                    if event.key == pygame.K_SPACE:
                        if lvl == 1:
                            text1 = font.render("Lvl: 1", 1, (255, 0, 0))
                            text1_x=1
                            text1_y=1
                            screen.blit(text1, (text1_x, text1_y))
                            maze.reinit(10, 2, screen, fcoords)
                            hero.movetostart(screen, wall, maze, fin)
                        if lvl == 2:
                            text1 = font.render("Lvl: 2", 1, (255, 0, 0))
                            text1_x=1
                            text1_y=1
                            screen.blit(text1, (text1_x, text1_y))        
                            maze.reinit(30, 6, screen, fcoords)
                            hero.movetostart(screen, wall, maze, fin)
                        if lvl == 3:
                            text1 = font.render("Lvl: 3", 1, (255, 0, 0))
                            text1_x=1
                            text1_y=1
                            screen.blit(text1, (text1_x, text1_y))
                            maze.reinit(30, 10, screen, fcoords)
                            hero.movetostart(screen, wall, maze, fin)
                        if lvl == 4:
                            text1 = font.render("Lvl: 4", 1, (255, 0, 0))
                            text1_x = 1
                            text1_y = 1
                            screen.blit(text1, (text1_x, text1_y))
                            maze.reinit(20, 20, screen, fcoords)
                            hero.movetostart(screen, wall, maze, fin)
                        if lvl == 5:
                            text1 = font.render("Lvl: 5", 1, (255, 0, 0))
                            text1_x = 1
                            text1_y=1
                            screen.blit(text1, (text1_x, text1_y))
                            maze.reinit(5, 40, screen, fcoords)
                            hero.movetostart(screen, wall, maze, fin)
                    if event.key == pygame.K_i:
                        the_running = True
                        while the_running:
                            text1 = font.render("Lvl: infinity", 1, (255, 0, 0))
                            text1_x = 1
                            text1_y = 1
                            screen.blit(text1, (text1_x, text1_y))
                            pygame.display.flip()
                            running2 = True
                            print(running2)
                            block2 = False
                            maze.reinit(random.randint(0, 40), random.randint(0, 40), screen, fcoords)
                            fin = Finish()
                            fcoords = list(fin.coords())
                            hero.movetostart(screen, wall, maze, fin)
                            while running2:
                                if not block2:
                                    for event in pygame.event.get():
                                        if event.type == pygame.KEYDOWN:
                                            if event.key == pygame.K_w or event.key == pygame.K_UP:
                                                motion = 'UP'
                                            if event.key == pygame.K_s or event.key == pygame.K_DOWN:
                                                motion = 'DOWN'
                                            if event.key == pygame.K_a or event.key == pygame.K_LEFT:
                                                motion = 'LEFT'
                                            if event.key == pygame.K_d or event.key == pygame.K_RIGHT:
                                                motion = 'RIGHT'
                                            if event.key == pygame.K_SPACE:
                                                text1 = font.render("Lvl: ∞", 1, (255, 0, 0))
                                                text1_x = 1
                                                text1_y = 1
                                                screen.blit(text1, (text1_x, text1_y))
                                                maze.reinit(random.randint(0, 40), random.randint(0, 40), screen, fcoords)
                                                hero.movetostart(screen, wall, maze, fin)
                                            if event.key == pygame.K_o:
                                                the_running = False
                                                running2 = False
                                            if event.type == pygame.QUIT:
                                                running2 = False
                                                running = False
                                                the_running = False
                                                close = True
                                    x = list(hero.coords())[0]
                                    y = list(hero.coords())[1]
                                    if motion == 'RIGHT':
                                        if (x + 1, y) not in maze.blockcoords() and (x + 1, y) not in maze.movingblockcoords():
                                            hero.moveright(screen, wall, maze, fin)
                                        if (x + 2, y) not in maze.blockcoords() and (x + 1, y) in maze.movingblockcoords() and (x + 2, y) not in maze.movingblockcoords():
                                            maze.moveblock(maze.movingblockcoords().index((x + 1, y)), "x", "+", screen, wall, hero, fin)
                                        fin.finish(hero.coords())
                                        motion = ''
                                    if motion == 'UP':
                                        if (x, y - 1) not in maze.blockcoords() and (x, y - 1) not in maze.movingblockcoords():
                                            hero.moveup(screen, wall, maze, fin)
                                        if (x, y - 2) not in maze.blockcoords() and (x, y - 1) in maze.movingblockcoords() and (x, y - 2) not in maze.movingblockcoords():
                                            maze.moveblock(maze.movingblockcoords().index((x, y - 1)), "y", "-", screen, wall, hero, fin)
                                        fin.finish(hero.coords())
                                        motion = ''
                                    if motion == 'LEFT':
                                        if (x - 1, y) not in maze.blockcoords() and (x - 1, y) not in maze.movingblockcoords():
                                            hero.moveleft(screen, wall, maze, fin)
                                        if (x - 2, y) not in maze.blockcoords() and (x - 1, y) in maze.movingblockcoords() and (x - 2, y) not in maze.movingblockcoords():
                                            maze.moveblock(maze.movingblockcoords().index((x - 1, y)), "x", "-", screen, wall, hero, fin)
                                        fin.finish(hero.coords())
                                        motion = ''
                                    if motion == 'DOWN':
                                        if (x, y + 1) not in maze.blockcoords() and (x, y + 1) not in maze.movingblockcoords():
                                            hero.movedown(screen, wall, maze, fin)
                                        if (x, y + 2) not in maze.blockcoords() and (x, y + 1) in maze.movingblockcoords() and (x, y + 2) not in maze.movingblockcoords():
                                            maze.moveblock(maze.movingblockcoords().index((x, y + 1)), "y", "+", screen, wall, hero, fin)
                                        fin.finish(hero.coords())
                                        motion = ''
                                    if fin.finished():
                                        block2 = True
                                        running2 = False
                                    pygame.display.flip()
                                if close:
                                    break

                    if event.type == pygame.QUIT:
                        running = False
                        close = True
            x = list(hero.coords())[0]
            y = list(hero.coords())[1]
            if motion == 'RIGHT':
                if (x + 1, y) not in maze.blockcoords() and (x + 1, y) not in maze.movingblockcoords():
                    hero.moveright(screen, wall, maze, fin)
                if (x + 2, y) not in maze.blockcoords() and (x + 1, y) in maze.movingblockcoords() and (x + 2, y) not in maze.movingblockcoords():
                    maze.moveblock(maze.movingblockcoords().index((x + 1, y)), "x", "+", screen, wall, hero, fin)
                fin.finish(hero.coords())
                motion = ''
            if motion == 'UP':
                if (x, y - 1) not in maze.blockcoords() and (x, y - 1) not in maze.movingblockcoords():
                    hero.moveup(screen, wall, maze, fin)
                if (x, y - 2) not in maze.blockcoords() and (x, y - 1) in maze.movingblockcoords() and (x, y - 2) not in maze.movingblockcoords():
                    maze.moveblock(maze.movingblockcoords().index((x, y - 1)), "y", "-", screen, wall, hero, fin)
                fin.finish(hero.coords())
                motion = ''
            if motion == 'LEFT':
                if (x - 1, y) not in maze.blockcoords() and (x - 1, y) not in maze.movingblockcoords():
                    hero.moveleft(screen, wall, maze, fin)
                if (x - 2, y) not in maze.blockcoords() and (x - 1, y) in maze.movingblockcoords() and (x - 2, y) not in maze.movingblockcoords():
                    maze.moveblock(maze.movingblockcoords().index((x - 1, y)), "x", "-", screen, wall, hero, fin)
                fin.finish(hero.coords())
                motion = ''
            if motion == 'DOWN':
                if (x, y + 1) not in maze.blockcoords() and (x, y + 1) not in maze.movingblockcoords():
                    hero.movedown(screen, wall, maze, fin)
                if (x, y + 2) not in maze.blockcoords() and (x, y + 1) in maze.movingblockcoords() and (x, y + 2) not in maze.movingblockcoords():
                    maze.moveblock(maze.movingblockcoords().index((x, y + 1)), "y", "+", screen, wall, hero, fin)
                fin.finish(hero.coords())
                motion = ''
            if fin.finished():
                block = True
                running = False
            pygame.display.flip()
    if close:
        break